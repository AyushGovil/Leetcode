class Solution:
    def solution(self, board: List[List[str]]) -> None:
        lis=[]
        for i in range(len(board)):
            for j in range(len(board[0])):
                if board[i][j]=='.':
                    lis.append((i,j))
        def check(i,j,number):
            rowno=(i//3)*3
            colno=(j//3)*3
            
            for k in range(rowno,rowno+3):
                for m in range(colno,colno+3):
                    if number==board[k][m]:
                        return False
            for z in range(9):
                if board[i][z]==number or board[z][j]==number:
                    return False
            return True
    
        def bactrack(lis,index):
            for i in range(1,10):
                q=str(i)
                if check(lis[index][0],lis[index][1],q):
                    
                    
                    x,y=lis[index][0],lis[index][1]
                    board[x][y]=q
                    if len(lis)-index==1:
                        return True
                    if bactrack(lis,index+1):
                        return True
                    else:
                        board[x][y]='.'
            return False
     
        bactrack(lis,0)
        return board
        