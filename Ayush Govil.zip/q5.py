import heapq
class Solution:
    def solution(self, nums: List[int], k: int) -> int:
        h=[]
        heapq.heapify(h)
        
        size=0
        for i in nums:
            if size<k:
                heapq.heappush(h,i)
                size+=1
            else:
                if i<h[0]:
                    continue
                else:
                    heapq.heappop(h)
                    heapq.heappush(h,i)
        return h[0]