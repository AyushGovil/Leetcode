class Solution:
    def solution(self, matrix, target):
        
        for i in matrix:
            l=0
            h=len(i)
            while(l!=h):
                
                mid=(l+h)//2
                if i[mid]==target:
                    return True
                if target<i[mid]:
                    h=mid
                else:
                    l=mid+1
        return False