def __init__(self):
        self.stack=[]
        self.pop1=[]

    def push(self, x: int) -> None:
        self.stack.append(x)
        

    def pop(self) -> int:
        if len(self.pop1)==0:
            while(self.stack):
                self.pop1.append(self.stack.pop())
        return self.pop1.pop()

    def peek(self) -> int:
        if len(self.pop1)==0:
            while(self.stack):
                self.pop1.append(self.stack.pop())
        return self.pop1[-1]
        

    def empty(self) -> bool:
        if len(self.stack)==0 and len(self.pop1)==0:
            return True
        return False
        