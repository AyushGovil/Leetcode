

class Solution:
    def solution(self, root: TreeNode) -> int:
        if root==None:
            return 0
        self.max=1
        def max2(root,height):
            if root==None:
                return
            
            self.max=max(self.max,height)
            max2(root.left,height+1)
            max2(root.right,height+1)
        max2(root,1)
        return self.max
            
            