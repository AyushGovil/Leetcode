def solution(self, s: str) -> bool:
        lis=[]
        top=-1
        for i in s:
            if(i=="{" or i=="[" or i=="("):
                lis.append(i)
                top+=1
                continue
            if(i=="}"):
                if top==-1:
                    lis.append(i)
                    top+=1
                    continue
                if lis[top]=="{":
                    lis.pop()
                    top-=1
                    continue
                else:
                    lis.append(i)
                    top+=1
                    continue
            if(i=="]"):
                if top==-1:
                    lis.append(i)
                    top+=1
                    continue
                if lis[top]=="[":
                    lis.pop()
                    top-=1
                    continue
                else:
                    lis.append(i)
                    top+=1
                    continue
            if(i==")"):
                if top==-1:
                    lis.append(i)
                    top+=1
                    continue
                if lis[top]=="(":
                    lis.pop()
                    top-=1
                    continue
                else:
                    lis.append(i)
                    top+=1
                    continue
        if(top==-1):
            return True
        else:
            return False
        