def solution(self, height: List[int]) -> int:
        left=0
        max1=0
        output=0
        right=len(height)-1
        while(left<right):
            if height[left]<height[right]:
                max1=height[right]
                leftmax=height[left]
                left+=1
                while(height[left]<max1):
                    
                    if height[left]<leftmax:
                        output+=leftmax-height[left]
                        left+=1
                        
                    else:
                        leftmax=height[left]
                        left+=1
                
            if height[right]<=height[left]:
                max1=height[left]
                rightmax=height[right]
                right-=1
                
                while(height[right]<=max1):
                    
                    if right<=left:
                        break
                    if height[right]<=rightmax:
                        output+=rightmax-height[right]
                        right-=1
                    else:
                        rightmax=height[right]                
        return output